# coding=utf-8


from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


# keyboard
services_keyboard = InlineKeyboardMarkup()

# buttons
vk_button = InlineKeyboardButton("♦️ 𝗩𝗞.𝗖𝗢𝗠", callback_data="vk_service_chosen")
wa_button = InlineKeyboardButton("♦️ 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣", callback_data="wa_service_chosen")
tg_button = InlineKeyboardButton("♦️ 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", callback_data="tg_service_chosen")
ig_button = InlineKeyboardButton("♦️ 𝗧𝗜𝗞𝗧𝗢𝗞 ", callback_data="ig_service_chosen")

# build keyboard
services_keyboard.add(vk_button).add(ig_button).add(tg_button).add(wa_button)
