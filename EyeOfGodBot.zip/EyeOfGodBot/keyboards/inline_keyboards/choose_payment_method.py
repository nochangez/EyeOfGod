# coding=utf-8


from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


# keyboard
choose_payment_method_keyboard = InlineKeyboardMarkup()

# buttons
card_payment_method = InlineKeyboardButton("💳 Оплата картой", callback_data="payment_method_card")
# nick_payment_method = InlineKeyboardButton("🥝  Оплата по нику QIWI", callback_data="payment_method_nick")

# build keyboard
choose_payment_method_keyboard.add(card_payment_method)
