# coding=utf-8


from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from data.config import prices


# keyboard
get_sub_keyboard = InlineKeyboardMarkup()

# buttons
full_sub_button = InlineKeyboardButton(f"💷 Полный доступ {prices['limitless']}₽", callback_data="get_sub_full")
month_sub_button = InlineKeyboardButton(f"💵 Подписка на месяц {prices['month']}₽", callback_data="get_sub_month")

# build keyboard
get_sub_keyboard.add(full_sub_button).add(month_sub_button)
