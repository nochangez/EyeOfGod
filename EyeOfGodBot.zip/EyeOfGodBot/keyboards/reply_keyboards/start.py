# coding=utf-8


from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


# keyboard
start_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

# buttons
reviews_button = KeyboardButton("📚 Отзывы")
my_profile_button = KeyboardButton("🕵️‍ Мой профиль")
information_button = KeyboardButton("📕 Информация")
my_purchases_button = KeyboardButton("👜 Мои покупки")
start_searching_button = KeyboardButton("🔍 Начать поиск")

# build keyboard
start_keyboard.add(
    start_searching_button, my_profile_button
).add(
    my_purchases_button, reviews_button
).add(
    information_button
)
