# coding=utf-8


from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


# keyboard
another_address_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

# buttons
another_address_button = KeyboardButton("👁 Указать другой адрес")

# build keyboard
another_address_keyboard.add(another_address_button)
