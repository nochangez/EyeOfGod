# coding=utf-8


from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


# keyboard
back_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)

# buttons
back_button = KeyboardButton("🏡 Вернуться в главное меню")

# build keyboard
back_keyboard.add(back_button)
