# coding=utf-8


from random import randint

from pyqiwip2p import AioQiwiP2P

from data.config import tokens
from services.payment.payment_database_controller import PaymentDatabaseController


class Payment:
    def __init__(self, token=tokens['qiwi_token']):
        self.__token = token  # get qiwi token
        self.__qiwi = AioQiwiP2P(auth_key=self.__token)  # init qiwi

        # self.__payment_database_controller = PaymentDatabaseController()  # init payment database controller

    async def get_payment_status(self, bill_id):
        status = await self.__qiwi.check(bill_id=bill_id)  # get payment status
        return True if str(status.status) == "PAID" else False  # return payment status as bool

    @staticmethod
    async def generate_comment(user_id):
        random_number = randint(1000, 10000)  # generate random number
        comment = f"{user_id}_{random_number}"  # create comment

        return comment

    async def create_payment_card(self, amount: int):
        bill = await self.__qiwi.bill(amount=amount, lifetime=5)  # create payment
        bill_id = bill.bill_id  # get bill id
        bill_url = bill.pay_url  # get payment url

        return {
            'bill_id': bill_id,
            'bill_url': bill_url
        }  # return payment data

    async def create_payment_nick(self, amount: int, user_id: int):
        comment = await self.generate_comment(user_id)  # generate comment

        bill = await self.__qiwi.bill(amount=amount, comment=comment, pay_sources=['qw'])  # create payment
        bill_id = bill.bill_id  # get bill id
        bill_url = bill.pay_url  # get payment url

        return {
            'bill_id': bill_id,
            'bill_url': bill_url
        }  # return payment data
