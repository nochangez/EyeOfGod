# coding=utf-8


from data.services.database_controller import DatabaseController


class PaymentDatabaseController:
    def __init__(self):
        self.__database_controller = DatabaseController()  # init database controller

    async def add_payment(self, amount ):
        pass
