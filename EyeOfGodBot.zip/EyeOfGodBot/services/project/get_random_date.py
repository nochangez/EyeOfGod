# coding=utf-8


from random import randint
from datetime import datetime, timedelta


def random_date(start, end):
    delta = end - start
    return start + timedelta(randint(0, delta.days))


def get_random_date():
    start = datetime.strptime('01.01.2021', '%d.%m.%Y')
    end = datetime.strptime('01.04.2022', '%d.%m.%Y')
    date = random_date(start, end)

    return date.strftime('%d.%m.%Y')
