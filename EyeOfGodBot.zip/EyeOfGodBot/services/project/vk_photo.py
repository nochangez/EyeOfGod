# coding=utf-8


import os
import requests

import vk_api

from data.config import tokens, path_to_pictures


# init vk session and bot
vk_session = vk_api.VkApi(token=tokens['vk_token'])
bot = vk_session.get_api()


def get_profile_photo(username):
    try:
        username = str(username).split('/')
        username = username[-2] if len(username) > 1 and username[-1] == '' else username[-1]

        print(f"[{username}]")
        profile = bot.users.get(user_ids=username, fields="photo_max_orig")
        print(profile)

        photo_link = bot.users.get(user_ids=username, fields="photo_max_orig")[0].get('photo_max_orig')
        response = requests.get(url=photo_link).content

        os.remove(f"{path_to_pictures}profile.jpeg") if "profile.jpeg" in os.listdir(path_to_pictures) else None

        profile_photo = open(f"{path_to_pictures}profile.jpeg", 'wb')
        profile_photo.write(response)
        profile_photo.close()

        return open(f"{path_to_pictures}profile.jpeg", 'rb')
    except Exception as error:
        print(f"error {error}")
