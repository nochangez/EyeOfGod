# coding=utf-8


from telethon import TelegramClient
from telethon.tl.functions.users import GetFullUserRequest

from data.config import api_id, api_hash


# init telegram client
telegram_client = TelegramClient("eg_session", api_id=api_id, api_hash=api_hash)


async def get_user(user):
    user = str(user).split('/')
    user = user[-2] if len(user) > 1 and user[-1] == '' else user[-1]

    user_info = await telegram_client(GetFullUserRequest(user))  # get user info
    user_info = user_info.to_dict()

    return user_info


async def run(user):
    async with telegram_client:
        return await get_user(user)
