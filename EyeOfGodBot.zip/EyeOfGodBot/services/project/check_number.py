# coding=utf-8


from phonenumbers import parse, geocoder, carrier


def get_number_info(phone_number):
    my_number = parse(phone_number)  # parse phone number

    operator_brand = carrier.name_for_number(my_number, 'ru')  # get oper brand
    country_fullname = geocoder.description_for_number(my_number, 'ru')  # get country fullname

    return {
        "oper_brand": operator_brand,
        "country_fullname": country_fullname
    }  # return phone number info
