# coding=utf-8


import requests
from bs4 import BeautifulSoup as bs

from random_user_agent.user_agent import UserAgent


def get_user_info(username):
    user_agent_rotator = UserAgent()
    random_user_agent = user_agent_rotator.get_random_user_agent()

    headers = {
        "User-Agent": random_user_agent
    }  # headers

    username = str(username).split('/')
    username = username[-2] if len(username) > 1 and username[-1] == '' else username[-1]
    username = username.replace(username[0], '') if username[0] == '@' else username

    base_url = f"https://tiktok.com/@{username}"
    print(base_url)
    print(f"[{username}]")
    response = requests.get(url=base_url, headers=headers)

    soup = bs(response.text, "html.parser")

    try:
        print(response.text)
        with open('s.html', 'w') as s:
            s.write(response.text)

        print(soup.find_all('strong'))
        likes = soup.find_all('strong', {'title': 'Likes'})[0].text
        following = soup.find_all('strong', {'title': 'Following'})[0].text
        followers = soup.find_all('strong', {'title': 'Followers'})[0].text

        return {
            'likes': likes,
            'following': following,
            'followers': followers
        }
    except:
        return None
