# coding=utf-8


import json
import pprint
import requests

from random_user_agent.user_agent import UserAgent


# init user agent rotator
user_agent_rotator = UserAgent()


def get_number_info(phone_number):
    random_user_agent = user_agent_rotator.get_random_user_agent()  # get random user agent

    source_to_parse = "https://htmlweb.ru/geo/api.php?json&telcod="  # source to parse
    headers = {
        "User-Agent": random_user_agent
    }  # headers
    proxies = {
        "http": [
            'http://196.1.95.117:80',
            'http://85.195.104.71:80',
            'http://80.48.119.28:8080',
        ],
        "https": 'http://8.213.128.41:80'
    }  # proxies
    response = requests.get(url=f"{source_to_parse}{phone_number}", headers=headers, proxies=proxies)  # make request

    data = json.loads(response.text)  # get json data

    pprint.pprint(data)

    operator_brand = data.get('0').get('oper_brand')  # get operator brand
    country_fullname = data.get('country').get('fullname')  # get fullname of country

    return {
        'oper_brand': operator_brand,
        'country_fullname': country_fullname
    }  # return number info
