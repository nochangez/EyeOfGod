# coding=utf-8


from data.services.database_controller import DatabaseController


class FollowersController:
    def __init__(self):
        self.__database_controller = DatabaseController()  # init database controller

    async def add_follower(self, follower_id: int, follow_plan: str):
        add_follower_query = f"""INSERT INTO followers (follower_id, follow_plan)
                                VALUES ('{follower_id}', '{follow_plan}')"""  # add follower
        await self.__database_controller.execute_query(add_follower_query)  # make query

        if follow_plan == "month":
            delete_after_month_query = f"""CREATE EVENT delete_event_{follower_id}
                                          ON SCHEDULE AT CURRENT_TIMESTAMP + INTERVAL 30 DAY
                                          DO DELETE FROM followers WHERE added_at < NOW() - 
                                          INTERVAL 30 DAY and follower_id='{follower_id}'"""  # delete after month query
            await self.__database_controller.execute_query(delete_after_month_query)  # make query

    async def is_follower(self, follower_id: int):
        get_follower_query = f"SELECT * FROM followers WHERE follower_id='{follower_id}'"  # get follower
        follower_info = await self.__database_controller.get_data_execute_query(get_follower_query)  # get follower data

        return True if len(follower_info) != 0 else False

    async def get_follower(self, follower_id: int):
        get_follower_query = f"SELECT * FROM followers WHERE follower_id='{follower_id}'"  # get follower
        follower_info = await self.__database_controller.get_data_execute_query(get_follower_query)  # get follower data

        return follower_info
