# coding=utf-8


from os import listdir
from random import randint

from data.config import path_to_pictures


def get_random_photo(path=f"{path_to_pictures}fake_nude/"):
    files = listdir(path=path)  # get all files in directory

    random_index = randint(0, len(files) - 1)  # get random file index
    random_filename = files[random_index]  # get random filename

    abs_path_to_file = f"{path}/{random_filename}"  # get absolute path to random file
    random_file = open(abs_path_to_file, 'rb')  # get

    return random_file  # return random file object
