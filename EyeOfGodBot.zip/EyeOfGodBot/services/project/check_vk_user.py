# coding=utf-8


import vk_api

from data.config import tokens


# init vk session and bot
vk_session = vk_api.VkApi(token=tokens['vk_token'])
bot = vk_session.get_api()


def get_user(user):
    user = str(user).split('/')
    user = user[-2] if len(user) > 1 and user[-1] == '' else user[-1]

    user_info = bot.users.get(user_ids=user, fields='sex')
    print(user_info)

    return user_info
