# coding=utf-8


import asyncio
from random import randint

from aiogram import types

from data.config import bot
from keyboards.inline_keyboards.no_subscription import *


class TelegramAdditions:
    def __init__(self, message: types.Message):
        self.__message = message  # get message
        self.__chat_id = self.__message.chat.id  # get chat id

    async def start_searching_visual(self):
        request_to_server_message = "💻 <b>Запрос отправлен на сервер</b>\n\n" \
                                    "💻 Если спустя <b>4 секунды</b> не пришел ответ, то " \
                                    "такого адреса не существует, попробуйте указать другой"

        request_to_server = await self.__message.answer(request_to_server_message)  # send request to server message
        await asyncio.sleep(0.9)  # delay

        first_step_message = "☑️ <b>Отправка запроса на сервер</b>\n\n" \
                             "          ⏳ <code>ЗАГРУЗКА 17%</code>\n\n" \
                             "    🟥🟥🟥⬜⬜⬜⬜⬜⬜⬜"  # 17% of loading

        second_step_message = "☑ <b>Поиск интимок в переписках</b>\n\n️" \
                              "         ⏳ <code>ЗАГРУЗКА 50%</code>\n\n" \
                              "   🟥🟥🟥🟥🟥🟥⬜⬜⬜⬜"  # 50% of loading
        third_step_message = "☑ <b>Получение ответа</b>\n\n" \
                             "      ️    ⏳ <code>ЗАГРУЗКА 98%</code>\n\n" \
                             "    🟥🟥🟥🟥🟥🟥🟥🟥🟥⬜"  # 98% of loading

        first_step = await bot.edit_message_text(
            chat_id=self.__chat_id, message_id=request_to_server.message_id, text=first_step_message
        )  # send first step message
        await asyncio.sleep(1.7)  # delay

        second_step = await bot.edit_message_text(
            chat_id=self.__chat_id, message_id=first_step.message_id, text=second_step_message
        )  # send second step message
        await asyncio.sleep(1.7)  # delay

        third_step = await bot.edit_message_text(
            chat_id=self.__chat_id, message_id=second_step.message_id, text=third_step_message
        )  # send third step message
        await asyncio.sleep(1.7)  # delay

        await bot.delete_message(chat_id=self.__chat_id, message_id=third_step.message_id)  # delete last visual message

    async def no_subscription(self):
        no_subscription_message = "<b>Для просмотра всех интимных фотографий нужна " \
                                  "подписка.</b>\n\n" \
                                  "На аккаунте подписки - <b>не обнаружено.</b>"  # no sub message

        await self.__message.answer(no_subscription_message, reply_markup=get_sub_keyboard)  # send no sub message

    @staticmethod
    async def get_hack_details(nude_photos=True, dialogs=True, black_list=True, hidden_friends=False):
        dialogs = randint(121, 167) if dialogs else None
        black_list = randint(4, 53) if black_list else None
        nude_photos = randint(14, 142) if nude_photos else None
        hidden_friends = randint(1, 11) if hidden_friends else None

        hack_details = {
            "dialogs": dialogs,
            "black_list": black_list,
            "nude_photos": nude_photos,
            "hidden_friends": hidden_friends
        }  # hack details

        return hack_details
