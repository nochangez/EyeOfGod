# coding=utf-8


import os

from aiogram import Bot, Dispatcher, types

from data.services.redis_helper import RedisHelper


# project settings and tokens
tokens = {
    'vk_token': "4b10d31b0ac20645e5984e0d0afadf1c05d5977f3269bd81168cbeb9103f1dcdbf7d05494fe317e1c553c",  
    'qiwi_token': "eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6Ind4NjliMy0wMCIsInVzZXJfaWQiOiI3OTY4MjA5NDg3OCIsInNlY3JldCI6Ijc5ZTE4YWYxMGEyODA0NDk4NTFjN2ZkM2NhM2Y3ZTg1NWQyNGU3NjQ5NjcwMWQxZWZlNTZmYzM2YjkxZTkyZjAifX0=",
    'telegram_token': "5316166777:AAF99gUvBPM23yB_HZKdcqbn1sYxlMkUp0U"
}  # set tokens

prices = {
    'month': 1,  # цена за месячную подписку (в рублях)
    'limitless': 500  # цена за безлимитную подписку (в рублях)
}

admins = [650387714, 387869905, 5281674850]  # admins - админы
path_to_pictures = "/Users/nochanga/PycharmProjects/EyeOfGodBot/pictures/"  # abs path to pictures directory


# telegram client info
api_id = 19532976  # api id
api_hash = "9575ec9d8d93b0622fd4c2caf0cf1982"  # api hash


# callable objects
redis_helper = RedisHelper()  # init redis helper
bot = Bot(token=tokens['telegram_token'], parse_mode=types.ParseMode.HTML)  # init bot
dispatcher = Dispatcher(bot, storage=redis_helper.redis_storage)  # init dispatcher
