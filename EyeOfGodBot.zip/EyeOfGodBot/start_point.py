# coding=utf-8


import logging

from aiogram import executor

from data.config import dispatcher
from handlers.command_handlers.start import register_handlers_start
from handlers.text_handlers.reviews import register_handlers_reviews
from handlers.data_handlers.vk_service import register_handlers_vk_service
from handlers.text_handlers.my_profile import register_handlers_my_profile
from handlers.data_handlers.tg_service import register_handlers_tg_service
from handlers.data_handlers.wa_service import register_handlers_wa_service
from handlers.data_handlers.ig_service import register_handlers_ig_service
from handlers.text_handlers.information import register_handlers_information
from handlers.text_handlers.my_purchases import register_handlers_my_purchases
from handlers.data_handlers.buy_sub_point import register_handlers_buy_sub_point
from handlers.data_handlers.check_payment import register_handlers_check_payment
from handlers.text_handlers.start_searching import register_handlers_start_searching
from handlers.data_handlers.choose_payment_method import register_handlers_choose_payment_method


# logging info
logging.basicConfig(level=logging.DEBUG)


# command handlers
register_handlers_start(dispatcher)

# data handlers
register_handlers_vk_service(dispatcher)
register_handlers_tg_service(dispatcher)
register_handlers_wa_service(dispatcher)
register_handlers_ig_service(dispatcher)
register_handlers_buy_sub_point(dispatcher)
register_handlers_check_payment(dispatcher)
register_handlers_choose_payment_method(dispatcher)

# text handlers
register_handlers_reviews(dispatcher)
register_handlers_my_profile(dispatcher)
register_handlers_information(dispatcher)
register_handlers_my_purchases(dispatcher)
register_handlers_start_searching(dispatcher)


if __name__ == "__main__":
    executor.start_polling(dispatcher, skip_updates=True)
