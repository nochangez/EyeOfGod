# coding=utf-8


from aiogram import Dispatcher, types

from services.payment.qiwi import Payment
from data.config import redis_helper, bot, admins, prices
from services.project.followers_controller import FollowersController


# init payment
payment = Payment()

# init followers controller
followers_controller = FollowersController()


async def check_payment_card(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query
    callback_data = callback_query.data  # get data from callback query

    bill_id = callback_data.replace('check_payment_card_', '')  # get bill id from callback data

    await callback_query.answer()  # answer to callback query

    is_paid = await payment.get_payment_status(bill_id)  # get payment status
    if is_paid:
        amount = await redis_helper.decode_bytes(
            await redis_helper.redis_get('amount')
        )  # get amount

        follow_plans = {
            prices['month']: 'month',
            prices['limitless']: 'limitless'
        }  # get follow plans

        follow_plans_human = {
            'month': 'Месячная подписка',
            'limitless': 'Безлимитная подписка'
        }  # follow plans for human

        follower_id = callback_query.from_user.id  # get follower id
        follow_plan = follow_plans[int(amount)]  # get current follow plan

        success_payment_message = f"✅ <b>Счет успешно оплачен!</b>\n\n" \
                                  f"Теперь вы имеете подписку: <b>{follow_plans_human[follow_plan]}</b>\n\n" \
                                  f"<b>Наслаждайтесь!</b>\n\n" \
                                  f"<code>Если доступ не появится сразу, " \
                                  f"попробуйте снова через пять минут</code>"  # success payment message

        await message.edit_text(success_payment_message)  # send u r follower now message

        await followers_controller.add_follower(follower_id=follower_id, follow_plan=follow_plan)  # add follower
        new_follower_message = f"📥 <b>Новое пополнение!</b>\n\n" \
                               f"<b>Статус:</b> ✅\n" \
                               f"<b>Покупатель:</b> <b><a href='tg://user?id={follower_id}'>" \
                               f"{callback_query.from_user.first_name}</a></b>\n" \
                               f"<b>Сумма пополнения:</b> {amount} RUB\n" \
                               f"<b>План подписки:</b> {follow_plans_human[follow_plan]}\n"

        for admin_id in admins:
            try:
                await bot.send_message(admin_id, text=new_follower_message)  # send new follower message
            except Exception as error:
                print(error)
                continue
    else:
        await message.answer("❌ Не было поступления платежа!")  # payment was not paid


async def check_payment_nick(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await message.answer('I AM')  # I WORK!!!!

    await callback_query.answer()  # answer to callback query


def register_handlers_check_payment(dp: Dispatcher):
    dp.register_callback_query_handler(
        check_payment_card,
        lambda callback_query: callback_query.data and callback_query.data.startswith('check_payment_card_')
    )
    dp.register_callback_query_handler(
        check_payment_nick,
        lambda callback_query: callback_query.data and callback_query.data.startswith('check_payment_nick_')
    )
