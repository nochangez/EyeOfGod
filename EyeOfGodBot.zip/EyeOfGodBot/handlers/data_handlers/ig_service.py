# coding=utf-8


from random import randint

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import StatesGroup, State

from keyboards.reply_keyboards.back import *
from data.config import path_to_pictures, bot
from services.project.check_ig import get_user_info
from keyboards.reply_keyboards.another_address import *
from services.telegram.additions import TelegramAdditions
from services.project.random_photo import get_random_photo
from services.project.get_random_date import get_random_date
from services.project.followers_controller import FollowersController


followers_controller = FollowersController()


class GetIg(StatesGroup):
    waiting_for_ig = State()


async def send_yes_hack_message(
        likes: str,
        dialogs: str,
        username: str,
        following: str,
        black_list: str,
        nude_photos: str,
        followers: str,
        message: types.Message,
):
    yes_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                       f"💎 Информация в TikTok: <b>{username}</b>\n\n" \
                       "💎 <b>Дополнительная информация:</b>\n" \
                       f"✉ Адресная ссылка tiktok: <b>https://tiktok.com/@{username}/</b>\n\n" \
                       f"📘 Подписки: <b>{following}</b>\n" \
                       f"📕 Подписчики: <b>{followers}</b>\n" \
                       f"📗 Лайки: <b>{likes}</b>\n\n" \
                       f"⏳Дата взлома: <b>{get_random_date()}</b>\n\n" \
                       "🔎 Найдено:\n\n" \
                       f"📷 Интимных фотографий - ✅ <b>{nude_photos}</b> шт. найдено!\n" \
                       f"✉️ Переписок - ✅ <b>{dialogs}</b> шт. найдено!\n" \
                       f"🗃 Черный список - ✅ <b>{black_list}</b> чел. найдено!"

    await message.answer(yes_hack_message, reply_markup=back_keyboard, disable_web_page_preview=True)


async def ig_service(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await callback_query.answer()  # answer to callback query

    ig_service_photo = open(f"{path_to_pictures}ig_service.jpeg", 'rb')
    ig_service_message = "👁‍🗨 Укажите id или адрес тик ток\n\n" \
                         "🌐 Бот принимает тик ток ссылки данного типа:\n\n" \
                         "┌ karnaval\n" \
                         "├ http://www.tiktok.com/@karna.val\n" \
                         "├ https://tiktok.com/karna.val\n" \
                         "├ www.tiktok.com/karna.val\n" \
                         "└ tiktok.com/karna.val"

    await bot.send_photo(chat_id=message.chat.id, photo=ig_service_photo)
    await message.answer(ig_service_message, disable_web_page_preview=True)  # send ig blocked message

    await GetIg.waiting_for_ig.set()


async def ig_link_choosing(message: types.Message, state: FSMContext):
    user_info = get_user_info(message.text)

    follower_id = message.from_user.id
    is_follower = await followers_controller.is_follower(follower_id)

    tg_adds = TelegramAdditions(message)
    username = message.text

    start_searching_message = "💻 <b>Запрос отправлен на сервер</b>\n\n" \
                              "💻 Если спустя <b>4 секунды</b> не пришел ответ, то " \
                              "такого адреса TikTok не существует, попробуйте " \
                              "указать другой"  # start searching message
    user_does_not_exist_message = "Пользователь не был обнаружен в базе данных. " \
                                  "Попробуйте указать другой адрес"

    if user_info is not None:
        uname = str(username).split('/')
        uname = uname[-2] if len(uname) > 1 and uname[-1] == '' else uname[-1]
        uname = uname.replace(uname[0], '') if uname[0] == '@' else uname

        likes = user_info.get('likes')
        following = user_info.get('following')
        followers = user_info.get('followers')

        hack_details = await tg_adds.get_hack_details()

        dialogs = hack_details.get('dialogs')
        black_list = hack_details.get('black_list')
        nude_photos = hack_details.get('nude_photos')

        if uname != "karna.val":
            if randint(0, 100) < 70:
                try:
                    if not is_follower:
                        media = types.MediaGroup()

                        for i in range(3):
                            media.attach_photo(get_random_photo(f"{path_to_pictures}fake_nude/"))

                        yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')

                        await tg_adds.start_searching_visual()

                        await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)
                        await bot.send_media_group(chat_id=message.chat.id, media=media)

                        await send_yes_hack_message(
                            likes=likes, following=following, followers=followers, username=username,
                            dialogs=dialogs, nude_photos=nude_photos, black_list=black_list, message=message
                        )
                        await tg_adds.no_subscription()

                        await state.finish()
                    elif is_follower:
                        await tg_adds.start_searching_visual()

                        media = types.MediaGroup()

                        for i in range(3):
                            media.attach_photo(get_random_photo(f"{path_to_pictures}fake_nude/"))

                        yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')

                        await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)
                        await bot.send_media_group(chat_id=message.chat.id, media=media)

                        await send_yes_hack_message(
                            likes=likes, following=following, followers=followers, username=username,
                            dialogs=dialogs, nude_photos=nude_photos, black_list=black_list, message=message
                        )
                except Exception as error:
                    print(error)

                    await message.answer(start_searching_message)
                    await message.answer(user_does_not_exist_message, reply_markup=another_address_keyboard)

                    await state.finish()
            else:
                no_hack_photo = open(f"{path_to_pictures}no_hack_photo.jpeg", 'rb')  # get ho hack photo
                no_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                                  f"💎 Имя TikTok: <b>{username}</b>\n" \
                                  f"Дата взлома: <b>{get_random_date()}</b>\n\n" \
                                  "🔎 <b>Ничего не найдено:</b>\n" \
                                  "📷 Увы интимных фотографий не обнаружено!"  # no hack message

                await tg_adds.start_searching_visual()  # start visual searching

                await bot.send_photo(
                    chat_id=message.chat.id, photo=no_hack_photo,
                    caption=no_hack_message, reply_markup=another_address_keyboard
                )  # send no hacks found alert

                await state.finish()  # finish state
        else:
            if not is_follower:
                media = types.MediaGroup()

                p1 = open(f"{path_to_pictures}fake_nude/karnaval1.jpeg", 'rb')
                p2 = open(f"{path_to_pictures}fake_nude/karnaval2.jpeg", 'rb')

                media.attach_photo(p1)
                media.attach_photo(p2)

                yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')

                await tg_adds.start_searching_visual()

                await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)
                await bot.send_media_group(chat_id=message.chat.id, media=media)

                await send_yes_hack_message(
                    likes=likes, following=following, followers=followers, username=username,
                    dialogs=dialogs, nude_photos=nude_photos, black_list=black_list, message=message
                )
                await tg_adds.no_subscription()

                await state.finish()
            elif is_follower:
                await tg_adds.start_searching_visual()

                media = types.MediaGroup()

                p1 = open(f"{path_to_pictures}real_nude/karnaval1.jpeg", 'rb')
                p2 = open(f"{path_to_pictures}real_nude/karnaval2.jpeg", 'rb')

                media.attach_photo(p1)
                media.attach_photo(p2)

                yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')

                await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)
                await bot.send_media_group(chat_id=message.chat.id, media=media)

                await send_yes_hack_message(
                    likes=likes, following=following, followers=followers, username=username,
                    dialogs=dialogs, nude_photos=nude_photos, black_list=black_list, message=message
                )
    else:
        await message.answer(start_searching_message)
        await message.answer(user_does_not_exist_message, reply_markup=another_address_keyboard)

        await state.finish()

    await state.finish()


def register_handlers_ig_service(dp: Dispatcher):
    dp.register_callback_query_handler(
        ig_service,
        lambda callback_query: callback_query.data and callback_query.data == "ig_service_chosen",
        state=None
    )
    dp.register_message_handler(ig_link_choosing, state=GetIg.waiting_for_ig)
