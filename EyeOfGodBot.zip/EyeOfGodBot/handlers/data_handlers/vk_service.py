# coding=utf-8


from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.types import ReplyKeyboardRemove
from aiogram.dispatcher.filters.state import StatesGroup, State

from keyboards.reply_keyboards.back import *
from services.project.check_vk_user import get_user
from services.project.vk_photo import get_profile_photo
from keyboards.reply_keyboards.another_address import *
from services.project.random_photo import get_random_photo
from data.config import bot, path_to_pictures, redis_helper
from services.project.get_random_date import get_random_date
from services.telegram.additions import TelegramAdditions as ta
from services.project.followers_controller import FollowersController


# init followers controller
followers_controller = FollowersController()


class GetVk(StatesGroup):
    waiting_for_link = State()


async def send_yes_hack_message(
        user: str,
        tg_adds: ta,
        full_username: str,
        message: types.Message,
):
    hack_details = await tg_adds.get_hack_details(hidden_friends=True)  # get hack details
    hack_data = await redis_helper.redis_lrange('hack_data_vk', 0, 4)

    user_e = hack_data[-1].decode('utf-8') if len(hack_data) != 0 else user
    if str(user) == str(user_e) and len(hack_data) != 0:
        dialogs = hack_data[3].decode('utf-8')
        black_list = hack_data[2].decode('utf-8')
        nude_photos = hack_data[1].decode('utf-8')
        hidden_friends = hack_data[0].decode('utf-8')

        await redis_helper.redis_lpush('hack_data_vk', [user_e, dialogs, black_list, nude_photos, hidden_friends])
        await redis_helper.redis_expire('hack_data_vk', 300)
    else:
        dialogs = hack_details.get('dialogs')
        black_list = hack_details.get('black_list')
        nude_photos = hack_details.get('nude_photos')
        hidden_friends = hack_details.get('hidden_friends')

        await redis_helper.redis_lpush('hack_data_vk', [user, dialogs, black_list, nude_photos, hidden_friends])
        await redis_helper.redis_expire('hack_data_vk', 300)

    yes_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                       f"💎 Имя во Вконтакте: <b>{full_username}</b>\n" \
                       f"Дата взлома: <b>{get_random_date()}</b>\n\n" \
                       "🔎 <b>Найдено:</b>\n" \
                       f"📷 Интимных фотографий - ✅ <b>{nude_photos}</b> шт. найдено!\n" \
                       f"✉️ Переписок - ✅ <b>{dialogs}</b> шт. найдено!\n" \
                       f"📙 Черный список - ✅ <b>{black_list}</b> чел. найдено!\n" \
                       f"👥️ Скрытые друзья - ✅ <b>{hidden_friends}</b> чел. найдено!"  # yes hack message

    await message.answer(yes_hack_message, reply_markup=back_keyboard)  # send yes hack message


async def vk_service_start(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message

    await callback_query.answer()  # answer callback query

    vk_service_photo = open(f"{path_to_pictures}vk_service.jpeg", 'rb')  # get vk service photo
    vk_service_message = f"👁‍ Укажите id или адрес вконтакте\n\n" \
                         f"🌐 Бот принимает вк ссылки данного типа:\n\n" \
                         f"┌ https://vk.com/id153162173\n" \
                         f"├ vk.com/id153162173\n" \
                         f"├ id153162173\n" \
                         f"└ sharishaxd\n"  # vk service message

    await bot.send_photo(
        chat_id=message.chat.id, photo=vk_service_photo, reply_markup=ReplyKeyboardRemove()
    )  # send vk service message

    await bot.send_message(chat_id=message.chat.id,
                           text=vk_service_message, disable_web_page_preview=False)  # send vk service message

    await GetVk.waiting_for_link.set()  # set vk waiting state


async def vk_link_choosing(message: types.Message, state: FSMContext):
    try:
        get_user(message.text)[0]  # try to get result from user searching
    except IndexError:
        start_searching_message = "💻 <b>Запрос отправлен на сервер</b>\n\n" \
                                  "💻 Если спустя <b>4 секунды</b> не пришел ответ, то " \
                                  "такого адреса Вконтакте не существует, попробуйте " \
                                  "указать другой"  # start searching message
        user_does_not_exist_message = "Пользователь не был обнаружен в базе данных. " \
                                      "Попробуйте указать другой адрес"

        await message.answer(start_searching_message)  # send start searching message
        await message.answer(user_does_not_exist_message,
                             reply_markup=another_address_keyboard)  # send user does not exist message

        await state.finish()  # finish state

    tg_adds = ta(message)  # init telegram additions
    follower_id = message.from_user.id  # get follower_id
    user_info = get_user(message.text)[0]  # get user info

    is_follower = await followers_controller.is_follower(follower_id)  # is follower?

    if user_info.get('sex') != 1:
        if user_info.get('sex') == 2:
            full_username = f"{user_info.get('first_name')} {user_info.get('last_name')}"  # get full name of user

            no_hack_photo = open(f"{path_to_pictures}no_hack_photo.jpeg", 'rb')  # get ho hack photo
            no_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                              f"💎 Имя во Вконтакте: <b>{full_username}</b>\n" \
                              f"Дата взлома: <b>{get_random_date()}</b>\n\n" \
                              "🔎 <b>Ничего не найдено:</b>\n" \
                              "📷 Увы интимных фотографий не обнаружено!"  # no hack message

            await tg_adds.start_searching_visual()  # start visual searching

            await bot.send_photo(
                chat_id=message.chat.id, photo=no_hack_photo,
                caption=no_hack_message, reply_markup=another_address_keyboard
            )  # send no hacks found alert

            await state.finish()  # finish state
        else:
            await tg_adds.start_searching_visual()  # start visual searching
            await state.finish()  # finish state
    else:
        user = user_info.get('id')
        full_username = f"{user_info.get('first_name')} {user_info.get('last_name')}"  # get full name of user

        if not is_follower:
            if int(user) != 372549115:
                media = types.MediaGroup()
                for i in range(2):
                    media.attach_photo(get_random_photo())  # get fake fake_nude photo)
            else:
                shuga_photo = open(f"{path_to_pictures}шкурыгина.jpeg", 'rb')

            profile_photo = get_profile_photo(message.text)
            yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

            await tg_adds.start_searching_visual()  # start visual searching

            await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)  # send photo success hack
            await bot.send_photo(chat_id=message.chat.id, photo=profile_photo, caption="<b>Фото профиля Вконтакте:</b>")
            await bot.send_media_group(chat_id=message.chat.id, media=media) if int(user) != 372549115 else \
                await bot.send_photo(chat_id=message.chat.id, photo=shuga_photo)

            await send_yes_hack_message(
                user=user, tg_adds=tg_adds, full_username=full_username, message=message
            )  # send yes hack message
            await tg_adds.no_subscription()  # send sub buying menu

            await state.finish()  # finish state
        else:
            user = user_info.get('id')

            if int(user) != 372549115:
                media = types.MediaGroup()  # create media group
                for i in range(3):
                    media.attach_photo(get_random_photo(f"{path_to_pictures}real_nude/"))  # attach random photo
            else:
                shuga_photo = open(f"{path_to_pictures}шкурыгина.jpeg", 'rb')

            profile_photo = get_profile_photo(message.text)
            yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

            await tg_adds.start_searching_visual()  # start visual searching

            await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)  # send yes hack photo
            await bot.send_photo(chat_id=message.chat.id, photo=profile_photo, caption="<b>Фото профиля Вконтакте:</b>")
            await bot.send_media_group(chat_id=message.chat.id, media=media) if int(user) != 372549115 else \
                await bot.send_photo(chat_id=message.chat.id, photo=shuga_photo)

            await send_yes_hack_message(
                user=user, tg_adds=tg_adds, full_username=full_username, message=message
            )  # send yes hack message

            await state.finish()  # finish state

    await state.finish()  # finish state


def register_handlers_vk_service(dp: Dispatcher):
    dp.register_callback_query_handler(
        vk_service_start,
        lambda callback_query: callback_query.data and callback_query.data == "vk_service_chosen",
        state=None
    )
    dp.register_message_handler(vk_link_choosing, state=GetVk.waiting_for_link)
