# coding=utf-8


import phonenumbers

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.types import ReplyKeyboardRemove
from aiogram.dispatcher.filters.state import StatesGroup, State

from keyboards.reply_keyboards.back import *
from data.config import bot, path_to_pictures
from services.project.check_number import get_number_info
from services.project.random_photo import get_random_photo
from services.project.get_random_date import get_random_date
from services.telegram.additions import TelegramAdditions as ta
from services.project.followers_controller import FollowersController


# init followers controller
followers_controller = FollowersController()


class GetWa(StatesGroup):
    waiting_for_number = State()


async def send_yes_hack_message(
        phone_number: str,
        message: types.Message
):
    phone_number_info = get_number_info(phone_number)  # get number info

    operator_brand = phone_number_info.get('oper_brand')  # get oper brand
    country_fullname = phone_number_info.get('country_fullname')  # get country fullname

    yes_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                       f"💎 Номер в WhatsApp: <b>{phone_number}</b>\n\n" \
                       "💎 <b>Дополнительная информация:</b>\n" \
                       f"🌍 Страна: <b>{country_fullname}</b>\n" \
                       f"📱 Оператор: <b>{operator_brand}</b>\n\n" \
                       f"⏳Дата взлома: <b>{get_random_date()}</b>"  # yes hack message

    await message.answer(yes_hack_message, reply_markup=back_keyboard)  # send yes hack message


async def wa_service_start(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await callback_query.answer()  # answer callback query

    wa_service_photo = open(f"{path_to_pictures}wa_service.jpeg", 'rb')  # get wa service photo
    wa_service_message = f"👁‍🗨 Укажите номер телефона\n\n" \
                         f"🌐 Бот принимает номера данного типа:\n\n" \
                         f"┌ +79500475157\n" \
                         f"└ 79500475157\n"  # wa service message

    await bot.send_photo(chat_id=message.chat.id, photo=wa_service_photo,
                         reply_markup=ReplyKeyboardRemove())  # send wa service photo
    await message.answer(wa_service_message)  # send wa service message

    await GetWa.waiting_for_number.set()  # set waiting for phone number


async def wa_get_number(message: types.Message, state: FSMContext):
    phone_number = message.text  # get phone number
    incorrect_phone_number_message = "Вы указали несуществующий номер"  # incorrect phone number message

    another_number_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    another_number_button = KeyboardButton("👁 Указать другой номер")

    another_number_keyboard.add(another_number_button)

    if 12 >= len(phone_number) >= 11:
        regexp_phone_number = phone_number.replace(phone_number[0], '') if phone_number[0] == '+' else phone_number

        if regexp_phone_number.isdigit():
            phone_number = f"+{phone_number}" if phone_number[0] != '+' else phone_number  # add + symbol in phone num
            my_number = phonenumbers.parse(phone_number)  # get number

            if phonenumbers.is_valid_number(my_number):
                tg_adds = ta(message)  # init tg adds

                follower_id = message.from_user.id  # follower id
                is_follower = await followers_controller.is_follower(follower_id)  # is follower?

                if not is_follower:
                    media = types.MediaGroup()
                    for i in range(2):
                        media.attach_photo(get_random_photo())

                    yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

                    await tg_adds.start_searching_visual()  # start visual searching

                    await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)  # send yes hack photo
                    await bot.send_media_group(chat_id=message.chat.id, media=media)  # send fake_nude photo

                    await send_yes_hack_message(
                        phone_number=phone_number, message=message
                    )  # send yes hack message
                    await tg_adds.no_subscription()  # send no sub message

                    await state.finish()  # finish state
                else:
                    media = types.MediaGroup()  # create media group
                    for i in range(3):
                        media.attach_photo(get_random_photo(f"{path_to_pictures}real_nude/"))  # attach random photo

                    yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

                    await tg_adds.start_searching_visual()  # start visual searching

                    await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)  # send yes hack photo
                    await bot.send_media_group(chat_id=message.chat.id, media=media)  # send 3 photos

                    await send_yes_hack_message(
                        phone_number=phone_number, message=message
                    )  # send yes hack message

                    await state.finish()  # finish state
            else:
                await message.answer(incorrect_phone_number_message,
                                     reply_markup=another_number_keyboard)  # send incorrect phone number message

                await state.finish()  # finish state
        else:
            await message.answer(incorrect_phone_number_message,
                                 reply_markup=another_number_keyboard)  # send incorrect phone number message

            await state.finish()  # finish state
    else:
        await message.answer(incorrect_phone_number_message,
                             reply_markup=another_number_keyboard)  # send incorrect phone number alert

        await state.finish()  # finish state

    await state.finish()  # finish state


def register_handlers_wa_service(dp: Dispatcher):
    dp.register_callback_query_handler(
        wa_service_start,
        lambda callback_query: callback_query.data and callback_query.data == "wa_service_chosen",
        state=None
    )
    dp.register_message_handler(wa_get_number, state=GetWa.waiting_for_number)
