# coding=utf-8


from aiogram import Dispatcher, types

from keyboards.inline_keyboards.choose_payment_method import *
from data.config import redis_helper, path_to_pictures, bot, prices


async def buy_sub_point(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query
    callback_data = callback_query.data  # get callback data from callback query

    await callback_query.answer()  # answer callback query

    amount = prices['limitless'] if callback_data == "get_sub_full" else prices['month']  # get sub amount
    await redis_helper.redis_set('amount', amount)  # set amount value

    buy_sub_point_photo = open(f"{path_to_pictures}buy_sub_point_photo.jpeg", 'rb')  # get buy sub point photo
    buy_sub_point_message = "Выберите метод оплаты"  # buy sub point message

    await bot.send_photo(
        chat_id=message.chat.id, photo=buy_sub_point_photo,
        caption=buy_sub_point_message, reply_markup=choose_payment_method_keyboard
    )  # send choose payment method


def register_handlers_buy_sub_point(dp: Dispatcher):
    dp.register_callback_query_handler(
        buy_sub_point,
        lambda callback_query: callback_query.data and callback_query.data.startswith("get_sub")
    )
