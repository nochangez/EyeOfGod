# coding=utf-8


from aiogram import Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from services.payment.qiwi import Payment
from keyboards.reply_keyboards.back import *
from data.config import path_to_pictures, redis_helper, bot


# init payment
payment = Payment()


async def payment_method_start(message: types.Message):
    success_preparing_photo = open(f"{path_to_pictures}buy_sub_photo.jpeg", 'rb')  # get success preparing photo
    success_preparing_message = "💎 Подготовка формы для оплаты прошла успешно"  # success preparing message

    await bot.send_photo(
        chat_id=message.chat.id, photo=success_preparing_photo,
        caption=success_preparing_message, reply_markup=back_keyboard
    )  # send success preparing message


async def payment_method_nick(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await callback_query.answer()  # answer to callback query
    await payment_method_start(message)  # call start message

    amount = await redis_helper.decode_bytes(
        await redis_helper.redis_get('amount')
    )  # get amount
    bill = await payment.create_payment_nick(amount=int(amount), user_id=int(message.from_user.id))  # create nick pay

    await message.answer(bill.get('bill_url'))  # send test alert


async def payment_method_card(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await callback_query.answer()  # answer to callback query
    await payment_method_start(message)  # call start message

    amount = await redis_helper.decode_bytes(
        await redis_helper.redis_get('amount')
    )  # get sub price
    bill = await payment.create_payment_card(amount=int(amount))  # create bill for card payment method

    card_payment_message = "📒 <b>Подготовленный счет к оплате</b>\n\n" \
                           f"💵 Сумма к оплате: <code>{amount}</code> руб\n" \
                           "⏳ Счет действителен: <code>5</code> минуты\n" \
                           "🤖 После оплаты, нажмите кнопку '💻  Проверить оплату'\n" \
                           "После оплаты бот выдаст архив с интим-фото"  # card payment message

    card_payment_keyboard = InlineKeyboardMarkup()  # keyboard

    payment_card_button = InlineKeyboardButton("💳 Оплатить с карты", url=bill.get('bill_url'))  # url to payment bill
    check_payment_button = InlineKeyboardButton(
        "💻 Проверить оплату", callback_data=f'check_payment_card_{bill.get("bill_id")}'
    )  # check payment button

    card_payment_keyboard.add(payment_card_button).add(check_payment_button)  # build keyboard

    await message.answer(card_payment_message, reply_markup=card_payment_keyboard)  # send bill


def register_handlers_choose_payment_method(dp: Dispatcher):
    dp.register_callback_query_handler(
        payment_method_nick,
        lambda callback_query: callback_query.data and callback_query.data == "payment_method_nick"
    )
    dp.register_callback_query_handler(
        payment_method_card,
        lambda callback_query: callback_query.data and callback_query.data == "payment_method_card"
    )
