# coding=utf-8


from random import randint

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.types import ReplyKeyboardRemove
from aiogram.dispatcher.filters.state import StatesGroup, State

from keyboards.reply_keyboards.back import *
from services.project.check_tg_user import run
from keyboards.reply_keyboards.another_address import *
from services.telegram.additions import TelegramAdditions
from services.project.random_photo import get_random_photo
from data.config import bot, path_to_pictures, redis_helper
from services.project.get_random_date import get_random_date
from services.project.followers_controller import FollowersController


# init followers controller
followers_controller = FollowersController()


class GetTg(StatesGroup):
    waiting_for_link = State()


async def send_yes_hack_message(
        user: str,
        access_hash: str,
        full_username: str,
        message: types.Message,
        tg_adds: TelegramAdditions
):
    hack_details = await tg_adds.get_hack_details(
        dialogs=True,
        black_list=True,
        nude_photos=True
    )  # get hack details
    hack_data = await redis_helper.redis_lrange('hack_data_tg', 0, 3)
    print(hack_data)

    user_e = hack_data[-1].decode('utf-8') if len(hack_data) != 0 else user
    if str(user) == str(user_e) and len(hack_data) != 0:
        dialogs = hack_data[2].decode('utf-8')
        black_list = hack_data[1].decode('utf-8')
        nude_photos = hack_data[0].decode('utf-8')

        await redis_helper.redis_lpush('hack_data_tg', [user_e, dialogs, black_list, nude_photos])
        await redis_helper.redis_expire('hack_data_tg', 300)
    else:
        dialogs = hack_details.get('dialogs')
        black_list = hack_details.get('black_list')
        nude_photos = hack_details.get('nude_photos')

        await redis_helper.redis_lpush('hack_data_tg', [user, dialogs, black_list, nude_photos])
        await redis_helper.redis_expire('hack_data_tg', 300)

    tg_yes_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                          f"💎 Имя в Telegram: <b>{full_username}</b>\n\n" \
                          "💎 <b>Дополнительная информация:</b>\n" \
                          f"🧑‍💻 Хэш доступа: <b>{access_hash}</b>\n\n\n" \
                          f"⏳Дата взлома: <b>{get_random_date()}</b>\n\n" \
                          f"🔎 <b>Найдено:</b>\n" \
                          f"📷 Интимных фотографий - ✅ <b>{nude_photos}</b> шт. найдено!\n" \
                          f"✉️ Переписок - ✅ <b>{dialogs}</b> шт. найдено!\n" \
                          f"📙 Черный список - ✅ <b>{black_list}</b> чел. найдено!"  # yes hack message

    await message.answer(tg_yes_hack_message, reply_markup=back_keyboard)  # send yes hack message


async def tg_service_start(callback_query: types.CallbackQuery):
    message = callback_query.message  # get message from callback query

    await callback_query.answer()  # answer callback query

    tg_service_photo = open(f"{path_to_pictures}tg_service.jpeg", 'rb')  # get tg service photo
    tg_service_message = "👁‍ Укажите id или адрес телеграмма\n\n" \
                         "🌐 Бот принимает телеграм ссылки данного типа:\n\n" \
                         "┌ https://t.me/Le_li_ck\n" \
                         "├ @Le_li_ck\n" \
                         "└ Le_li_ck"  # tg service message

    await bot.send_photo(
        chat_id=message.chat.id, photo=tg_service_photo, reply_markup=ReplyKeyboardRemove()
    )  # send tg service photo

    await message.answer(tg_service_message, disable_web_page_preview=False)  # send tg service message

    await GetTg.waiting_for_link.set()  # set waiting for link state


async def tg_link_choosing(message: types.Message, state: FSMContext):
    request_sent_message = "💻 <b>Запрос отправлен на сервер</b>\n\n" \
                           "💻 Если спустя <b>4 секунды</b> не пришел ответ, " \
                           "то такого телеграмма не существует, попробуйте " \
                           "указать другой"  # request sent message
    no_user_found_message = f"Пользователь не был обнаружен в базе данных. " \
                            f"Попробуйте указать другой адрес"  # no user found message

    if not message.text.isdigit():
        try:
            user_info = await run(message.text)  # get user info

            follower_id = message.from_user.id  # follower id
            last_name = user_info.get('user').get('last_name')  # get last name
            first_name = user_info.get('user').get('first_name')  # get first name
            access_hash = user_info.get('user').get('access_hash')  # get access hash
            full_username = f"{first_name} {last_name}" if last_name is not None else first_name  # build full username

            is_follower = await followers_controller.is_follower(follower_id)  # is follower?

            tg_adds = TelegramAdditions(message)  # init telegram additions

            if randint(0, 100) < 80:
                if not is_follower:
                    media = types.MediaGroup()
                    for i in range(2):
                        media.attach_photo(get_random_photo(f"{path_to_pictures}fake_nude/"))

                    tg_yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

                    await tg_adds.start_searching_visual()  # start visual searching

                    await bot.send_photo(chat_id=message.chat.id, photo=tg_yes_hack_photo)  # send yes hack photo
                    await bot.send_media_group(chat_id=message.chat.id, media=media)  # send fake_nude photo

                    await send_yes_hack_message(
                        full_username=full_username, message=message, tg_adds=tg_adds,
                        access_hash=str(access_hash), user=first_name
                    )  # send yes hack message
                    await tg_adds.no_subscription()  # send no sub message

                    await state.finish()  # finish state
                else:
                    media = types.MediaGroup()  # create media group
                    for i in range(3):
                        media.attach_photo(get_random_photo(f"{path_to_pictures}real_nude/"))  # attach random photo

                    yes_hack_photo = open(f"{path_to_pictures}yes_hack_photo.jpeg", 'rb')  # get yes hack photo

                    await tg_adds.start_searching_visual()  # start visual searching

                    await bot.send_photo(chat_id=message.chat.id, photo=yes_hack_photo)  # send yes hack photo
                    await bot.send_media_group(chat_id=message.chat.id, media=media)  # send 3 photos

                    await send_yes_hack_message(
                        full_username=full_username, message=message, tg_adds=tg_adds,
                        access_hash=str(access_hash), user=first_name
                    )  # send yes hack message

                    await state.finish()  # finish state
            else:
                no_hack_photo = open(f"{path_to_pictures}no_hack_photo.jpeg", 'rb')  # get ho hack photo
                no_hack_message = "📒 <b>Полученная информация</b>\n\n" \
                                  f"💎 Имя Telegram: <b>{full_username}</b>\n" \
                                  f"Дата взлома: <b>{get_random_date()}</b>\n\n" \
                                  "🔎 <b>Ничего не найдено:</b>\n" \
                                  "📷 Увы интимных фотографий не обнаружено!"  # no hack message

                await tg_adds.start_searching_visual()  # start visual searching

                await bot.send_photo(
                    chat_id=message.chat.id, photo=no_hack_photo,
                    caption=no_hack_message, reply_markup=another_address_keyboard
                )  # send no hacks found alert

                await state.finish()  # finish state
        except Exception as error:
            print(error)

            await message.answer(request_sent_message)  # send request sent message
            await message.answer(no_user_found_message,
                                 reply_markup=another_address_keyboard)  # send no user found message

            await state.finish()  # finish state
    else:
        await message.answer(request_sent_message)  # send request sent message
        await message.answer(no_user_found_message, reply_markup=another_address_keyboard)  # send no user found message

        await state.finish()  # finish state

    await state.finish()  # finish state


def register_handlers_tg_service(dp: Dispatcher):
    dp.register_callback_query_handler(
        tg_service_start,
        lambda callback_query: callback_query.data and callback_query.data == "tg_service_chosen",
        state=None
    )
    dp.register_message_handler(tg_link_choosing, state=GetTg.waiting_for_link)
