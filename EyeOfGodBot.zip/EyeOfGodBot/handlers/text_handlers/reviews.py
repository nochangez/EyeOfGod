# coding=utf-8


from aiogram import Dispatcher, types

from data.config import bot, path_to_pictures
from keyboards.reply_keyboards.back import *


async def reviews(message: types.Message):
    reviews_message = "📝 Написано отзывов: <u>188</u>\n" \
                      "🤖 Бот работает с: <u>17</u> Декабря <u>2021</u> Года"  # reviews message
    reviews_photo = open(f"{path_to_pictures}reviews_photo.jpeg", 'rb')  # get reviews photo

    await bot.send_photo(
        chat_id=message.chat.id, caption=reviews_message,
        photo=reviews_photo, reply_markup=back_keyboard
    )  # send reviews message


def register_handlers_reviews(dp: Dispatcher):
    dp.register_message_handler(
        reviews,
        lambda message: message.text and message.text == "📚 Отзывы"
    )
