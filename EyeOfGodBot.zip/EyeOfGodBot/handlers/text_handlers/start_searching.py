# coding=utf-8


from aiogram import Dispatcher, types
from aiogram.types import ReplyKeyboardRemove

from data.config import bot, path_to_pictures
from keyboards.inline_keyboards.choose_service import *


async def start_searching(message: types.Message):
    start_searching_photo = open(f"{path_to_pictures}searching_photo.jpeg", 'rb')  # get start searching photo
    start_searching_message = "Выберите социальную сеть по которой будет происходить поиск\n\n" \
                              "👇 <u>Для выбора просто кликни по кнопке ниже.</u>"  # start searching message

    await bot.send_photo(
        chat_id=message.chat.id,
        photo=start_searching_photo,
        reply_markup=ReplyKeyboardRemove(),
        caption="🔍 <b>Поиск информации по соц.сетям:</b>"
    )  # send start searching

    await message.answer(start_searching_message, reply_markup=services_keyboard)  # send searching service keyboard


def register_handlers_start_searching(dp: Dispatcher):
    dp.register_message_handler(
        start_searching,
        lambda message: message.text and message.text == "🔍 Начать поиск" or (message.text == "👁 Указать другой адрес" or message.text == "👁 Указать другой номер")
    )
