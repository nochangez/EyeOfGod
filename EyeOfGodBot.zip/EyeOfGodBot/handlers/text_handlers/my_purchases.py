# coding=utf-8


from aiogram import Dispatcher, types

from keyboards.reply_keyboards.back import *
from data.config import bot, path_to_pictures
from keyboards.inline_keyboards.no_subscription import *
from services.project.followers_controller import FollowersController


# init followers controller
followers_controller = FollowersController()


async def my_purchases(message: types.Message):
    user_id = message.from_user.id  # get user id

    follower_info = await followers_controller.get_follower(user_id)  # get follower info
    follow_plan = follower_info[0][2] if len(follower_info) != 0 else "Не обнаружено"  # get follow plan

    follow_money = {
        'Не обнаружено': 0,
        'month': prices['month'],
        'limitless': prices['limitless'],
    }  # set balance for follow plans

    follow_plan_human = {
        'month': 'Месячная подписка',
        'Не обнаружено': 'Не обнаружено',
        'limitless': 'Безлимитная подписка'
    }  # set follow plan human

    purchases = follow_plan_human[follow_plan] if follow_plan_human[follow_plan] == 'Не обнаружено' \
        else f"{follow_plan_human[follow_plan]} ({follow_money[follow_plan]}₽)"  # get user purchases

    my_purchases_message = "👜 Мои покупки\n\n" \
                           f"🆔 <u>{user_id}</u>\n" \
                           f"💼 Покупок: <u>{purchases}</u>"  # my purchases message
    my_purchases_photo = open(f"{path_to_pictures}my_purchases_photo.jpeg", 'rb')  # get my purchases photo

    await bot.send_photo(
        chat_id=message.chat.id, photo=my_purchases_photo, reply_markup=back_keyboard
    )  # send my purchases message

    await message.answer(my_purchases_message, reply_markup=get_sub_keyboard) if purchases == "Не обнаружено" else \
        await message.answer(my_purchases_message)


def register_handlers_my_purchases(dp: Dispatcher):
    dp.register_message_handler(
        my_purchases,
        lambda message: message.text and message.text == "👜 Мои покупки"
    )
