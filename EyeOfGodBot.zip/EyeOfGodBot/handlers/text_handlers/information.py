# coding=utf-8


from random import randint

from aiogram import Dispatcher, types

from keyboards.reply_keyboards.back import *
from data.config import bot, path_to_pictures, redis_helper


async def write_bot_data():
    try:
        await redis_helper.decode_bytes(await redis_helper.redis_get('users'))  # all users in bot
    except AttributeError:
        await redis_helper.redis_set('users', 1475)  # all users in bot
        await redis_helper.redis_set('users_online', 19)  # online users in bot

        await redis_helper.redis_set('vk_checked', 237)  # all vk checks
        await redis_helper.redis_set('ig_checked', 145)  # all ig checks
        await redis_helper.redis_set('tg_checked', 182)  # all tg checks

    users = await redis_helper.decode_bytes(await redis_helper.redis_get('users'))  # all users in bot
    users_online = await redis_helper.decode_bytes(
        await redis_helper.redis_get('users_online')
    )  # online users in bot

    vk_checked = await redis_helper.decode_bytes(await redis_helper.redis_get('vk_checked'))  # all vk checks
    ig_checked = await redis_helper.decode_bytes(await redis_helper.redis_get('ig_checked'))  # all ig checks
    tg_checked = await redis_helper.decode_bytes(await redis_helper.redis_get('tg_checked'))  # all tg checks

    change_users = bool(randint(0, 1))  # decide to change users
    change_online = bool(randint(0, 1))  # decide to change users online

    change_vk = bool(randint(0, 1))  # decide to change vk
    change_ig = bool(randint(0, 1))  # decide to change ig
    change_tg = bool(randint(0, 1))  # decide to change tg

    users = int(users) + 1 if change_users else users
    users_online = int(users_online) + 1 if change_online else int(users_online) - 1
    await redis_helper.redis_set('users', users)
    await redis_helper.redis_set('users_online', users_online)

    vk_checked = int(vk_checked) + 1 if change_vk else vk_checked
    ig_checked = int(ig_checked) + 1 if change_ig else ig_checked
    tg_checked = int(tg_checked) + 1 if change_tg else tg_checked
    await redis_helper.redis_set('vk_checked', vk_checked)
    await redis_helper.redis_set('ig_checked', ig_checked)
    await redis_helper.redis_set('tg_checked', tg_checked)

    drain_hacks = int(vk_checked) + int(ig_checked) + int(tg_checked)  # all hacks

    bot_information = {
        "users": users,
        "users_online": users_online,
        "vk_checked": vk_checked,
        "ig_checked": ig_checked,
        "tg_checked": tg_checked,
        "drain_hacks": drain_hacks
    }  # bot info as json

    return bot_information


async def information(message: types.Message):
    bot_information = await write_bot_data()  # get bot info

    bot_information_photo = open(f"{path_to_pictures}information_photo.jpeg", 'rb')  # get bot information photo
    bot_information_message = f"🟢 Пользователей онлайн в боте: <u>{bot_information['users_online']}</u>\n\n" \
                              f"👤 Пользователей: <u>{bot_information['users']}</u>\n" \
                              f"👨‍💻 Проверено VK: <u>{bot_information['vk_checked']}</u>\n" \
                              f"👨‍💻 Проверено instagram: <u>{bot_information['ig_checked']}</u>\n" \
                              f"👨‍💻 Проверено telegram: <u>{bot_information['tg_checked']}</u>\n\n" \
                              f"🔥 Найдено сливов всего: " \
                              f"<u>{bot_information['drain_hacks']}</u>"  # get bot information message

    await bot.send_photo(
        chat_id=message.chat.id, caption="📈 <b>Информация бота</b>:", photo=bot_information_photo
    )  # send first part of bot information

    await message.answer(bot_information_message, reply_markup=back_keyboard)  # send second part of bot information


def register_handlers_information(dp: Dispatcher):
    dp.register_message_handler(
        information,
        lambda message: message.text and message.text == "📕 Информация"
    )
