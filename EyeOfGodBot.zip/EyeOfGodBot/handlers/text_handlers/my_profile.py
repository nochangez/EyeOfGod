# coding=utf-8


from aiogram import Dispatcher, types

from keyboards.reply_keyboards.back import *
from data.config import bot, path_to_pictures, prices
from services.project.followers_controller import FollowersController


# init followers controller
followers_controller = FollowersController()


async def get_profile(message: types.Message):
    user_id = message.from_user.id  # get user id

    follower_info = await followers_controller.get_follower(user_id)  # get follower info
    follow_plan = follower_info[0][2] if len(follower_info) != 0 else "Не обнаружено"  # get follow plan

    follow_money = {
        'Не обнаружено': 0,
        'month': prices['month'],
        'limitless': prices['limitless'],
    }  # set balance for follow plans

    follow_plan_human = {
        'month': 'Месячная подписка',
        'Не обнаружено': 'Не обнаружено',
        'limitless': 'Безлимитная подписка'
    }  # set follow plan human

    balance = follow_money[follow_plan]  # get balance
    subscription = follow_plan_human[follow_plan]  # get subscription

    my_profile_photo = open(f"{path_to_pictures}my_profile_photo.jpeg", 'rb')  # get profile photo
    my_profile_message = f"<b>🕵️‍ Мой профиль</b>\n\n" \
                         f"🆔 <u>{user_id}</u>\n" \
                         f"💼 Подписка: <u>{subscription}</u>\n\n" \
                         f"💳 Баланс: <u>{balance}</u>₽"  # my profile message

    await bot.send_photo(
        photo=my_profile_photo, chat_id=message.chat.id,
        caption=my_profile_message, reply_markup=back_keyboard
    )  # send my profile message


def register_handlers_my_profile(dp: Dispatcher):
    dp.register_message_handler(
        get_profile,
        lambda message: message.text and message.text == "🕵️‍ Мой профиль"
    )
