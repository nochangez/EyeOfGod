# coding=utf-8


from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text

from data.config import bot, path_to_pictures
from keyboards.reply_keyboards.start import *


async def process_start_command(message: types.Message, state: FSMContext):
    await state.finish()  # finish all states if they are

    start_message = "👋 Это поисковый бот Глаз Бога 18+!\n\n" \
                    "👁 <b>Бот</b> проверяет базу на 📱 <b>Интимные переписки 🍑 Фото и 🎥 Видеоматериалы</b> " \
                    "интимного характера и использует для поиска <u>закрытые</u> и <u>приватные</u> базы данных.\n\n" \
                    "💎 Платформа работает на основе <b>новых революционных технологий</b>, которые дают " \
                    "возможность получать данные с <u>приватных ресурсов</u> в " \
                    "режиме реального времени."  # start message
    start_photo = open(f"{path_to_pictures}start_photo.jpeg", 'rb')  # get start photo

    await bot.send_photo(
        chat_id=message.chat.id, photo=start_photo,
        caption=start_message, reply_markup=start_keyboard
    )  # send start message


def register_handlers_start(dp: Dispatcher):
    dp.register_message_handler(process_start_command, commands=['start'])
    dp.register_message_handler(process_start_command, Text(equals="🏡 Вернуться в главное меню"))
