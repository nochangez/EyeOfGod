# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

from random_proxies.proxies import random_proxy
from random_proxies.proxies.settings import __version__
