# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

class TimeoutError(Exception):
    pass

class NoSuchProxyError(Exception):
    pass

class CountryCodeError(Exception):
    pass
