# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.ERROR)

logger = logging.getLogger(__package__)